#include <stdio.h>
#include <stdlib.h>
#include "Calculator.h"




/*
TODO
1. check if memory is freed after allocating
2. Create Stack




1. Get Input (String)
2. Tokenize
3. 
*/

int main(void) {
	Calculate();
	return 0;
}

