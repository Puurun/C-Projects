#include <stdio.h>
#include <stdlib.h>
#include "Calculator.h"




/*
TODO

1. add other operations (cos, sin, tan, ...etc)
2. add a more complicated cui

*/

int main(void) {
	Calculate();
	return 0;
}

