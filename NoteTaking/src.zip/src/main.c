#include <stdio.h>
#include "Note.h"

int main(void){
	MainWindow();
	return 0;
}
